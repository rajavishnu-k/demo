package test;

import java.io.File;

import org.junit.jupiter.api.Test;

import controller.DicomViewerController;
import model.DCMParser;
import view.ImportFile;
import view.Viewer;


class UnitTestDicomViewer {

	@Test
	void test() throws Exception {
		DicomViewerController dicomViewerController = new DicomViewerController(new DCMParser());
		dicomViewerController.parseDCMFile(new File("D:\\Dicom Viewer-Project\\DicomViewer\\src\\dcmfiles\\"));
		//dicomViewerController.parseDCMFile(new File("C:\\Users\\1026837\\Downloads\\old\\Home.java"));
		
		
		
	//	new DCMParser().splitTime("");
		
	}

}
