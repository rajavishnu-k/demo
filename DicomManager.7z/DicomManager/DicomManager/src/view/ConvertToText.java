package view;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import org.dcm4che3.data.Attributes;
import org.dcm4che3.data.Tag;
import org.dcm4che3.io.DicomInputStream;

import controller.DicomViewerController;
import model.DCMParser;

public class ConvertToText {

//	static 
//	static File f = new File("C:\\Users\\1026807\\Downloads\\FW__\\93679240.dcm");

	public static File convertToText(File f) throws Exception {		
		Writer w = null;
		try {					
			DicomViewerController controller = new DicomViewerController(new DCMParser());
			controller.parseDCMFile(f);
			Attributes tagDataSet = DicomViewerController.getTagSet();
			String dicomFileName = f.getName();
			File TextDcm = new File(dicomFileName+".txt");
			FileOutputStream is = new FileOutputStream(TextDcm);
			OutputStreamWriter osw = new OutputStreamWriter(is);
			w = new BufferedWriter(osw);		
			w.write(tagDataSet.toString());			
			return TextDcm;		
		} catch (Exception ex) {
			throw ex;
		}
		finally {			
			w.close();
		}

	}
}