package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;


import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dao.ImageDAO;

import javax.swing.JTable;
import javax.swing.JScrollPane;

public class ImageDetails extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTable table;

	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the dialog.
	 */
	
	public ImageDetails(String study,String series,String image)
	{
		setResizable(false);
		Toolkit t = Toolkit.getDefaultToolkit();
        Dimension d = t.getScreenSize();
        int h = d.height ;
        int w = d.width;
        setBounds(w/2-917/2, h/2-481/2, 917, 481);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(27, 46, 856, 296);
		getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setBounds(100, 100, 850, 500);
		scrollPane.setViewportView(table);
		DefaultTableModel dtm=new DefaultTableModel();
		table.setModel(dtm);
		dtm.addColumn("Description");
		dtm.addColumn("Value");
		
		
		
		try {
		
		LinkedHashMap<String, String> imgDetails = ImageDAO.details(study, series, image);
		Set<String> keys = imgDetails.keySet();
		Iterator<String> itr = keys.iterator();
		while(itr.hasNext()) {
			String key = (String)itr.next();
			String value=(String)imgDetails.get(key);
			//System.out.println(key + " " + imgDetails.get(key) + "\n");
			dtm.addRow(new Object[] {key,value});
		}
		
	
		table.setModel(dtm);
		table.setVisible(true);
		
	} catch (Exception ex) {
		ex.printStackTrace();
	}
		
	}
}
