package test;

import java.io.File;

import org.junit.jupiter.api.Test;

import controller.DicomViewerController;
import model.DCMParser;

class UnitTestDicomViewer {

	@Test
	void test() throws Exception {
		DicomViewerController dicomViewerController = new DicomViewerController(new DCMParser());
		dicomViewerController.parseDCMFile(new File("D:\\Dicom Viewer-Project\\DicomViewer\\src\\dcmfiles\\"));	
		
	//	new DCMParser().splitTime("");
		
	}

}
